$(document).ready( function() {
		$('#searchform').hide();
		$('#searchparam').hide();
});